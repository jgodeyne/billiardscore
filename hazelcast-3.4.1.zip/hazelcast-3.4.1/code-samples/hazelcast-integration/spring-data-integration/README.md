<h1>Spring Data Integration with Hazelcast</h1>
In this repository, you can find a sample implementation of MongoDB persistence integrated with Spring Data-MongoDB module. You can also find detailed explanation at http://hazelcast.org/docs/3.2/manual/html/springintegration.html#spring-data-mongodb

<h2>Prerequisites</h2>
You should have installed Apache Maven(http://maven.apache.org/download.cgi).

<h2>How to Compile</h2>
- run the code:
```
mvn compile
```