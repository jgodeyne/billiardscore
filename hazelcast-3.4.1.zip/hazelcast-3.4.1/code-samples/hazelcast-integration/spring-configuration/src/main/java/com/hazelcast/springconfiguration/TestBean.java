package com.hazelcast.springconfiguration;

/**
 * Created by Mustafa Orkun Acar <mustafaorkunacar@gmail.com> on 07.07.2014.
 */

public class TestBean
{
    private String result;
    public String getResult() { return result; }
    public void setResult(String Result) { result = Result; }
}