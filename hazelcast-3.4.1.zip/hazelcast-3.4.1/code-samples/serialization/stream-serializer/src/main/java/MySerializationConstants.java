public class MySerializationConstants {
    private static int ID = 1;
    public static final int PERSON_TYPE = ID++;
    public static final int CAR_TYPE = ID++;
    public static final int HASHMAP_TYPE = ID++;
    public static final int LINKEDLIST_TYPE = ID++;
    public static final int EXTENDED_ARRAYLIST_TYPE = ID++;
}
