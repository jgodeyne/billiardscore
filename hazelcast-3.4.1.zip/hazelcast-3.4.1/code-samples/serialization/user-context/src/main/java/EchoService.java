public class EchoService {
    public void echo(String msg) {
        System.out.println(msg);
    }
}