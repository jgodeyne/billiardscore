#!/bin/sh

#-Dhazelcast.socket.bind.any=false
java -cp target/lib/*:target/classes  Member