To generate the keyfile, the following command was used:

keytool -genkey -alias mydomain -keyalg RSA -keystore keystore.jks -keysize 2048

The provided password was 'password'.